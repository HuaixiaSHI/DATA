function fx = fitness(ch, N, M, q, qmax, D, RT, DT, ST, cf, ce, cl, cp, epsilon, theta, ct, alpha1, alpha2, beta, eta, cc)
%
x = ch(1:N);
y = ch(N+1:end);
cost = zeros(M,1);        % ���������Ķ�Ӧ�ĳɱ�
kCar = 1;
punish = 0;
for m = 1 : M
    u = find(y == m);      % �ֿ�k���ǵ������
    if isempty(u)
        cost(m) = 0;
        punish = punish + 1;
    else
        route = x(ismember(x, u)) + M;   % �ֿ�k���ǵĿͻ�������˳��
        route = Tsp2Vrp (route, q, qmax);
        route(route == 0) = m;
        % ����ɱ�
       
        ddist = 0;        % ������ʻ�ľ���
        C2 = 0;
        C3 = 0;
        C4 = 0;
        C5 = 0;
        % ���㳵��װ����
        QI = 0;
        for k = 2 : length(route)
            QI = QI +  q(route(k));
            if route(k) <= M
                break
            end
        end
        % ���Ƴ���ʱ��
        st = getst(RT(route(2)), D(route(1),route(2)));
        nowtime = st;
        for j = 2 : length(route)
            ddist = ddist + D(route(j-1),route(j));
            dt = changeSpeed(nowtime, D(route(j-1),route(j)));
            nowtime = nowtime + dt;
            % �ͷ��ɱ�
            if  route(j) > M
                C2 = C2 + ce * max(RT(route(j))-nowtime,0) + cl * max(nowtime-DT(route(j)),0);
            end
            % ��ʧ�ɱ�
            W = nowtime - st;
            C3 = C3 + cp * q(route(j)) * epsilon *exp((1-theta) * W);
            % �ͺĳɱ�
            C4 = C4 + ct * alpha1 * dt + ct * alpha2 * (dt + ST(route(j)));
            % ̼�ŷųɱ�
            EM = eta * (alpha1 * dt + alpha2 * (dt * ST(route(j))) + beta * D(route(j-1),route(j)) * QI);
            C5 = C5 + cc * EM;
            %
            QI = QI - q(route(j));
            nowtime = nowtime + ST(route(j));   % ����ʱ��
            if route(j) == m         % ����õ�����������
                  C3 = 0;
                  C4 = 0;
                  C5 = 0;
               % cost0 = cf + C2 + C2 + C3 + C4 + C5;
               cost0 = ddist+C2;
            
               %cost0 = C2+ddist+C3+C4+C5;
                cost(m) = cost(m) + cost0;
                % ��һ����
                kCar = kCar + 1;
                ddist = 0;
                C2 = 0;
                C3 = 0;
                C4 = 0;
                C5 = 0;
                % ���㳵��װ����
                QI = 0;
                for k = j+1 : length(route)
                    QI = QI +  q(route(k));
                    if route(k) <= M
                        break
                    end
                end
                if j < length(route)
                    % ���Ƴ���ʱ��
                    st = getst(RT(route(j+1)), D(route(j),route(j+1)));
                end
                nowtime = st;
            end
        end
    end
end
C = sum(cost);
fx = C + punish * 1e9;

