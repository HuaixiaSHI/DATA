function s = num2time(t)
h = fix(t);           % Сʱ
m = round((t - h) * 60);     % ����
if m >=10
    s = [num2str(h) ':' num2str(m)];
else
    s = [num2str(h) ':0' num2str(m)];
end
if m == 60
     s = [num2str(h+1) ':00'];
end