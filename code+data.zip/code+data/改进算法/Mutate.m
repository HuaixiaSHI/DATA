function X = Mutate(X, Pm1, Pm2, fit, M, N)
% ����
NP = size(X,1);
fave = mean(fit);
fmax = max(fit);
for i = 1 : NP
    x = X(i,1:N);
    y = X(i,N+1:N*2);
    fi = fit(i);
    if fi >= fave
        Pm = Pm1 - (Pm1 - Pm2) * (fmax - fi) / (fmax - fave);
    else
        Pm = Pm1;
    end
    if Pm >= rand
        r = randperm(N);
        x(r(1:2)) = x(r(2:-1:1));
    end
    % ѡַ����
    if Pm >= rand
        r = randi(N);
        y(r) = randi(M);
    end
    X(i,:) = [x y ];
end